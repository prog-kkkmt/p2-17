class Professions:
    """Объявляет класс профессий."""
    def __init__(self, prof_code, title):
        """Объявление полей класса."""
        self.prof_code = prof_code
        self.title = title

    def show(self):
        """Вывод"""
        print(self.prof_code, self.title)