class Vacancies:
    """Объявляет вакансии."""
    def __init__(self, vacancy_code, publication_date, title, salary, relevance, prof_code, edu_code, level_code):
        """Объявление полей."""
        self.vacancy_code = vacancy_code
        self.publication_date = publication_date
        self.title = title
        self.salary = salary
        self.relevance = relevance
        self.prof_code = prof_code
        self.edu_code = edu_code
        self.level_code = level_code

    def show(self):
        """Вывод."""
        print(self.vacancy_code, self.publication_date, self.title, self.salary, self.relevance,
              self.prof_code, self.edu_code, self.level_code)