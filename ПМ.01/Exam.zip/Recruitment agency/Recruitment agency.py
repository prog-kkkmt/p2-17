# Импортирование всех модулей с классами.
from posts import Posts
from computer_lvl import Level
from education import Education
from professions import Professions
from vacancies import Vacancies


def read_file_posts(file_name):
    """Чтение файла с должностями."""
    posts = []
    with open(file_name) as file_handler:
        for line in file_handler:
            res = line.split()
            posts.append(Posts(int(res[0]), res[1]))
    return posts


def read_file_professions(file_name):
    """Чтение файла с профессиями."""
    professions = []
    with open(file_name) as file_handler:
        for line in file_handler:
            res = line.split()
            professions.append(Professions(int(res[0]), res[1]))
    return professions


def read_file_education(file_name):
    """Чтение файла с образованием."""
    education = []
    with open(file_name) as file_handler:
        for line in file_handler:
            res = line.split()
            education.append(Education(int(res[0]), res[1]))
    return education


def read_file_level(file_name):
    """Чтение файла с уровнем владения компьютера."""
    level = []
    with open(file_name) as file_handler:
        for line in file_handler:
            res = line.split()
            level.append(Level(int(res[0]), res[1]))
    return level


def read_file_vacancies(file_name):
    """Чтение файла с вакансиями."""
    vacancy = []
    with open(file_name) as file_handler:
        for line in file_handler:
            res = line.split()
            vacancy.append(Vacancies(int(res[0]), res[1], res[2], int(res[3]), int(res[4]),
                                   int(res[5]), int(res[6]), int(res[7])))
    return vacancy

def current_vacancies(vacancy):
    """Проверка актуальности вакансии."""
    for el in vacancy:
        if el.relevance == 0:
            print(el.title)

def menu():
    """Обявление условного меню."""
    print("------------------------------")
    print("1) Должности")
    print("2) Профессии")
    print("3) Образование")
    print("4) Уровни владения компьютером")
    print("5) Все вакансии")
    print("6) Выход")




def main():
    posts = read_file_posts("Posts.txt") # Чтение файла с должностями.
    professions = read_file_professions("Professions.txt") # Чтение файла с профессиями.
    education = read_file_education("Education.txt") # Чтение файла с образованием.
    level = read_file_level("Level.txt") # Чтение файла с уровнем владения компьютера.
    vacancy = read_file_vacancies("Vacancy.txt") # Чтение файла с вакансиями.
    print("Список актуальный вакансий: ")
    print("------------------------------")
    current_vacancies(vacancy)
    menu()
    choice = ' '
    while choice != '6': # Меню выбора действий программы.
        choice = int(input())
        if choice == 1: # Вывод всех должностей.
            for el in posts:
                el.show()
        elif choice == 2: # Вывод всех профессий.
            for el in professions:
                el.show()
        elif choice == 3: # Вывод образования.
            for el in education:
                el.show()
        elif choice == 4: # Вывод уровня владения компьютером.
            for el in level:
                el.show()
        elif choice == 5: # Вывод всех вакансий.
            for el in vacancy:
                el.show()
        elif choice == 6: # Выход из программы.
            break


if __name__ == "__main__":
    main()