class Posts:
    """Объявляет класс должностей."""
    def __init__(self, post_code, title):
        """Объявление полей."""
        self.post_code = post_code
        self.title = title

    def show(self):
        """Вывод."""
        print(self.post_code, self.title)