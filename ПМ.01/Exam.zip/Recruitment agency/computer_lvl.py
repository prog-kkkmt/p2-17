class Level:
    """Объявляет уровни владения компьютером."""
    def __init__(self, level_code, title):
        """Объявление полей класса."""
        self.level_code = level_code
        self.title = title

    def show(self):
        """Вывод."""
        print(self.level_code, self.title)