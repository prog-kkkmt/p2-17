class Education:
    """Объявляет класс образования."""
    def __init__(self, edu_code, title):
        """Объявление полей класса."""
        self.edu_code = edu_code
        self.title = title

    def show(self):
        """Вывод."""
        print(self.edu_code, self.title)