﻿#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "Books.h"
#include "Issue.h"
#include "Readers.h"

void read_books_file(std::vector<Books>& books, std::string name_file)
{
    std::ifstream in(name_file.c_str());
    int book_code;
    std::string title;
    std::string author_name;
    std::string genre;
    int year_publishing;
    while (in >> book_code >> title >> author_name >> genre >> year_publishing)
        books.push_back(Books(book_code, title, author_name, genre, year_publishing));
}

void read_readers_file(std::vector<Readers>& readers, std::string name_file)
{
    std::ifstream in(name_file.c_str());
    int reader_code;
    std::string fio;
    int ticket_number;
    while (in >> reader_code >> fio >> ticket_number)
        readers.push_back(Readers(reader_code, fio, ticket_number));
}

void read_issue_file(std::vector<Issue>& issue, std::string name_file)
{
    std::ifstream in(name_file.c_str());
    int reader_code;
    int book_code;
    std::string issue_date;
    while (in >> reader_code >> book_code >> issue_date)
        issue.push_back(Issue(reader_code, book_code, issue_date));
}

void most_popular_author(std::vector<Issue>& issue, std::vector<Books>& books)
{
    int num = issue[0].book_code;
    int max_frq = 1;
    for (int i = 0; i < issue.size() - 1; i++) {
        int frq = 1;
        for (int k = i + 1; k < issue.size(); k++)
            if (issue[i].book_code == issue[k].book_code)
                frq += 1;
        if (frq > max_frq) {
            max_frq = frq;
            num = issue[i].book_code;
        }
    }
    std::string fio;
    for (int i = 0; i < books.size(); i++)
        if (num == books[i].book_code)
        {
            fio = books[i].author_name;
            break;
        }
    std::cout << fio << std::endl;
}

void books_date(std::vector<Issue>& issue, std::vector<Books>& books)
{
    for (int i = 0; i < books.size(); i++)
        for(int j = 0; j < issue.size(); j++)
            if (books[i].book_code == issue[j].book_code)
            {
                std::cout << books[i].title << " " << issue[i].issue_date << std::endl;
            }
}

int main()
{
    std::vector<Books> books;
    std::vector<Readers> readers;
    std::vector<Issue> issue;
    read_books_file(books, "books.txt");
    read_readers_file(readers, "readers.txt");
    read_issue_file(issue, "issue.txt");
    std::cout << "The most popular author: ";
    most_popular_author(issue, books);
    std::cout << "Date Books:" << std::endl;
    books_date(issue, books);
    return 0;
}
