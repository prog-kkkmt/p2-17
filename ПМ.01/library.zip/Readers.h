#ifndef READERS_H_INCLUDED
#define READERS_H_INCLUDED

class Readers
{
public:
    int reader_code;
    std::string fio;
    int ticket_number;

    Readers(int reader_code, std::string fio, int ticket_number)
    {
        this->reader_code = reader_code;
        this->fio = fio;
        this->ticket_number = ticket_number;
    }
};


#endif // READERS_H_INCLUDED
