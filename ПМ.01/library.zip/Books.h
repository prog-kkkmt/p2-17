#ifndef BOOKS_H_INCLUDED
#define BOOKS_H_INCLUDED

class Books
{
public:
    int book_code;
    std::string title;
    std::string author_name;
    std::string genre;
    int year_publishing;

    Books(int book_code, std::string title, std::string author_name, std::string genre, int year_publishing)
    {
        this->book_code = book_code;
        this->title = title;
        this->author_name = author_name;
        this->genre = genre;
        this->year_publishing = year_publishing;
    }
};

#endif // BOOKS_H_INCLUDED
