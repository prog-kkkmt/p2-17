#ifndef ISSUE_H_INCLUDED
#define ISSUE_H_INCLUDED

class Issue
{
public:
    int reader_code;
    int book_code;
    std::string issue_date;

    Issue(int reader_code, int book_code, std::string issue_date)
    {
        this->reader_code = reader_code;
        this->book_code = book_code;
        this->issue_date = issue_date;
    }
};

#endif // ISSUE_H_INCLUDED
