#include <stdio.h>
#include "krNl.h"

int main()
{
	int masMain[3][3], b, c;

	funct1(masMain);
	funct2(masMain, b, c);

	return 0;
}
