int funct1(int b[3][3]);
int funct2(int a[3][3],int Mb, int Mc);
int funct3(int b[3][3], int Mb, int Mc);
int funct4(int a[3][3]);
int funct5(int a[3][3], int Mb);
int funct6(int a[3][3], int Mb);
