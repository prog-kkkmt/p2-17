#include <stdio.h>
#include "krNl.h"

int funct3(int b[3][3], int Mb, int Mc)
{
	switch(Mc)
        {
            case 1: 
                b[0][0] = Mb; break;
            case 2: 
                b[0][1] = Mb; break;
            case 3: 
                b[0][2] = Mb; break;
            case 4: 
                b[1][0] = Mb; break;
            case 5: 
                b[1][1] = Mb; break;
            case 6: 
                b[1][2] = Mb; break;
            case 7: 
                b[2][0] = Mb; break;
            case 8: 
                b[2][1] = Mb; break;
            case 9: 
                b[2][2] = Mb; break;
        }
}
//========================
int funct4(int a[3][3])
{
	for(int i = 0; i < 3; i++)
    {
        for(int j = 0; j < 3; j++)
            {
            printf("|%c|", a[i][j]);
            }
        printf("\n");
    }
}
//========================
