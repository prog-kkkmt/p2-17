#include <stdio.h>
#include "krNl.h"

int funct2(int a[3][3], int Mb, int Mc)
{
	int ret;
	for(int i = 0; i < 9; i++)
    {
        //Х или О
        if(i % 2 == 0)
            Mb = 'X';
        else
            Mb = 'O';
        ///Вставка элемента
        printf("Ход %c, Выбор ячейки поля для хода: ", Mb);
        scanf("%d", &Mc);
        funct3(a, Mb, Mc);
        funct4(a);
        ret = funct5(a, Mb);
        	if(ret == 1) return 1;
        ret = funct6(a, Mb);
        	if(ret == 1) return 1;
        if(i == 8)
            printf("draw\n");

    }
}
//========================
