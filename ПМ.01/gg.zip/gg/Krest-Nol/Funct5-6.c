#include <stdio.h>
#include "krNl.h"

int funct5(int a[3][3], int Mb)
{
	for(int i = 0; i < 3; i++)
        {
            if(a[i][0] == a[i][1] && a[i][1] == a[i][2] && a[i][0] != '*')
            {
                printf("WIN %c\n", Mb);
                return 1;
            }
            if(a[0][i] == a[1][i] && a[1][i] == a[2][i] && a[0][i] != '*')
            {
                printf("WIN %c\n", Mb);
                return 1;
            }	
        }
}
//========================
int funct6(int a[3][3], int Mb)
{
	for(int i = 0; i < 3; i++)
        {
            if(a[0][0] == a[1][1] && a[1][1] == a[2][2] && a[1][1] != '*')
            {
                printf("WIN %c\n", Mb);
                return 1;
            }
            if(a[0][2] == a[1][1] && a[1][1] == a[2][0] && a[0][2] != '*')
            {
                printf("WIN %c\n", Mb);
                return 1;
            }
        
        }
}