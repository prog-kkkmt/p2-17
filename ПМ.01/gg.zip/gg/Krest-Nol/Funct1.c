#include <stdio.h>
#include "krNl.h"

int funct1(int a[3][3])
{
	int shl = '1';
	for(int i = 0; i < 3; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            a[i][j] = shl++;
            printf("|%c|", a[i][j]);
        }
        printf("\n");
    }

	return 0;
}
//========================

//========================