sudo apt-get install libsfml-dev
g++ -c имя.cpp
g++ имя.o -o имя.exe -lsfml-graphics -lsfml-window -lsfml-system