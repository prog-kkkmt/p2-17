#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <ctime>
#include <cmath>
#include <cstring>
#include <vector>
#include <sstream>

#include "resourse/BobnevFunct.hpp"
#include "resourse/minigame1.hpp"
#include "resourse/menu.hpp"
#include "resourse/TanksGame.hpp"

using namespace std;
using namespace sf;

int BobnevGame();

int zapucs()
{
	int a = launcher();
	if(a == 10)
		BobnevGame();
	else if(a == 11)
	{
			KrestNol();
			zapucs();
	}
	else if(a == 12)
	{
		tanks();
		zapucs();
	}

	return 0;
}

int main()
{
	zapucs();
	return 0;
}

