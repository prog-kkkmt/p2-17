using namespace sf;

const int HEIGHT_MAP = 84;//размер карты высота
const int WIDTH_MAP = 60;//размер карты ширина 
 
 
String TileMap[HEIGHT_MAP] = {
"000000000000000000000000000000000000000000000000dddddddddddd",
"0                                               dddddddddddd",
"0                                               ddkkkkkkkkdd",
"0                                               ddkkkkkkkkdd",
"0                        z                      ddkkkkkkkkdd",
"0                                               ddkkkkkkkkdd",
"0   dZZkkkkkkddd                    D           ddkkkkkkkkdd",
"0   dddkkkkkkddd                                ddkkkkkkkkdd",
"0   ddkkkkkkkkZZ                                ZZkkkkkkkkdd",
"0   ddkkkkkkkkddS                               ddkkkkkkkkdd",
"0   ddkkkkkkkkddS                               ddkkkkkkkkdd",
"0   ddkkkkkkkkdd                                ddkkkkkkkkdd",
"0   ddkkkkkkkkdd                    ddddddZZddddddkkkkkkkkdd",
"0   ddkkkkkkkkdd                    dddZZZZdddddddkkkkkkkkdd",
"0   ddkkkkkkkkdd                    ddkkkkkkkkkkkkkkkkkkkkdd",
"0   ddkkkkkkkkdd                    kkkkkkkkkkkkkkkkkkkkkkdd",
"0   dZZZZZZddddd                    kkkkkkkkkkkkkkkkkkkkkkdd",
"0   ddddddZZZZZd                    kkkkkkkkkkkkkkkkkkkkkkdd",
"0                               z   kkkkkkkkkkkkkkkkkkkkkkZZ",
"0                                   kkkkkkkkkkkkkkkkkkkkkkZZ",
"0                                   kkkkkkkkkkkkkkkkkkkkkkdZ",
"0                                   ddkkkkkkkkkkkkkkkkkkkkdZ",
"0                                   ddddddddddddddkkkkkkkkdZ",
"0                                   ddddddddZZZdddkkkkkkkkdd",
"0                                              Sddkkkkkkkkdd",
"0                                               ddkkkkkkkkdZ",
"0                                               ddkkkkkkkkdd",
"0                       D                       ddkkkkkkkkdd",
"0                                               Zdkkkkkkkkdd",
"0                                      D        ddkkkkkkkkdd",
"0                                               ddkkkkkkkkdd",
"0                                               ddkkkkkkkkdd",
"0                                               ddkkkkkPkkdZ",
"0                                 ddddddddddddddddkkkkkkkkdd",
"0                  D              ddddddddddddddddkkkkkkkkdd",
"0                                               ddkkkkkkkkdd",
"0fffffffffffffffffffffV                         ddkkkkkkkkZd",
"0                     F                         ddkkkkkkkkdd",
"0fffffffffffffffffV   F                         ddkkkkkkkkdd",
"0                 F   F  z                      ddkkkkkkkkdd",
"0    D       D    F   F                         ddkkkkkkkkdd",
"0                 F   F                         ddkkkkkkkkdd",
"0  dddkkkkkkdddS  F   F              D       z  ddkkkkkkkkdd",
"0  dddkkkkkkddd   F   F                         ZZkkkkkkkkdd",
"0  ddkkkkkkkkdd   F   F                         ddkkkkkkkkdd",
"0  ddkkkkkkkkdd   F   F                         ZZkkkkkkkkdd",
"0  ddkkkkkkkkdd   F   F                         ddkkkkkkkkdd",
"0  ddkkkkkkkkdd   F   F                SS       ddkkkkkkkkdd",
"dddddkkkkkkkkdd   F   F            dddddddddddddddkkkkkkkkdd",
"dddddkkkkkkkkdd   F   F            ZZZZZZZddddddddkkkkkkkkdd",
"ZZkkkkkkkkkkkdd   F   F            ddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkdd   F   F            ddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkdZ   F   F            ddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkZZ   F   F            ddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkZZ   F   F            ddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkZZ   F   F            ddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkdZ   F   F           SZdkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkdd   F   F          SSddkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkdd   F   F            ddkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkdd   F   F            ddkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkdd   F   F            ddkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkdd   F   F            ddkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkdd   F   F            ddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkdd   F   F            ddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkdd   F   F           Sddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkddS                 SSddkkkkkkkkkkkddkkkkkkkkdd",
"ddkkkkkkkkkkkdddddddZZZZZZddddddddddddddddddddddddkkkkkkkkdd",
"ddkkkkkkkkkkkddddddddddZZdddddddddddddddddddddddddkkkkkkkkdd",
"ddkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"Zdkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"Zdkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"Zdkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"dZkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"dZkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"dZkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"ZZkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"ddkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkdd",
"dddddddddddddddddddddddddddddddZZZZZZZZZZZZZZZZZdddddddddddd",
"dddddddddddddddddddZZZZZZZZZZZZZZddddddddddddddddddddddddddd"
};

void randPy(char a)
{
	int randX, randY;
	srand(time(0));
	int countPy = 1;

	while(countPy > 0)
	{
		randX = 1 + rand() % (HEIGHT_MAP  - 1);
		randY = 1 + rand() % (WIDTH_MAP - 1);
		if(TileMap[randX][randY] == ' ')
		{
			TileMap[randX][randY] = a;
			countPy--;
		}
	}
}






