using namespace sf;

View view;

void getPlayerCoordinateForView(float x, float y)
{
	float tempX = x; float tempY = y;

	if (x < 400) tempX = 400;//убираем из вида левую сторону
	if (x > 1320) tempX = 1320;//убираем из вида левую сторону
	if (y < 400) tempY = 400;//верхнюю сторону
	if (y > 2088) tempY = 2088;//нижнюю сторону	

	view.setCenter(tempX + 100, tempY + 100);
}

void changeView()
{
	if(Keyboard::isKeyPressed(Keyboard::U))// отдаление
		view.zoom(1.005);
	if(Keyboard::isKeyPressed(Keyboard::J))// приближение
		view.zoom(0.9995);
	if (Keyboard::isKeyPressed(Keyboard::I))
		view.setSize(1000, 1000);//устанавливает размер камеры (наш исходный)
}