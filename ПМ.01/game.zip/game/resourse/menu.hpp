#include "menuClass.hpp"

using namespace std;
using namespace sf;

int launcher()
{
	RenderWindow window(VideoMode(800, 600), "MenuBobnevGame");

	float CurrentFrame = 0;
	int Value = 100;
	bool isOpen = false;
	Clock clock;

	Music music;
	music.openFromFile("soung/MusMenu.ogg");
	music.play();

	vector<Button>VecButton;

	VecButton.push_back(Button("Menu.png", 0, 0, 800, 600, 0 ,0)); //Фон
	VecButton.push_back(Button("ButtonsMenu.png", 0, 0, 251, 41, 500, 50)); // Играть
	VecButton.push_back(Button("ButtonsMenu.png", 0, 50, 251, 41, 500, 100)); //FAQ
	VecButton.push_back(Button("ButtonsMenu.png", 0, 100, 251, 41, 500, 150)); //Выход
	VecButton.push_back(Button("ButtonsMenu.png", 270, 0, 40, 31, 20, 550)); // Громче
	VecButton.push_back(Button("ButtonsMenu.png", 310, 0, 40, 31, 60, 550)); // Тише
	VecButton.push_back(Button("ButtonsMenu.png", 0, 150, 400, 380, 1000, 1000)); // Доп инфа
	VecButton.push_back(Button("ButtonsMenu.png", 350, 0, 40, 31, 100, 550)); // Доп игра
	VecButton.push_back(Button("ButtonsMenu.png", 350, 40, 40, 32, 140, 550)); // Доп игра



	while(window.isOpen())
	{
		Vector2i pixelPos = Mouse::getPosition(window);//забираем коорд курсора
		Vector2f pos = window.mapPixelToCoords(pixelPos);//переводим их в игровые (уходим от коорд окна)

		for (int i = 1; i < int(VecButton.size()); ++i)
		{
			VecButton[i].ButtonSpite.setColor(Color(61, 58, 58));
				if (VecButton[i].ButtonSpite.getGlobalBounds().contains(pos.x, pos.y))
					VecButton[i].ButtonSpite.setColor(Color::White);
		}



		srand(time(NULL));
		float time = clock.getElapsedTime().asMicroseconds();
		clock.restart();
		time = time / 800;

		Event work;
		while(window.pollEvent(work))
		{
			if(work.type == Event::Closed)
				window.close();
		else if(Mouse::isButtonPressed(Mouse::Left))
			{
				if(VecButton[3].ButtonSpite.getGlobalBounds().contains(pos.x, pos.y))
					return 0;
				else if(VecButton[1].ButtonSpite.getGlobalBounds().contains(pos.x, pos.y))
					return 10;
				else if(VecButton[4].ButtonSpite.getGlobalBounds().contains(pos.x, pos.y))
				{
					if(Value < 100)
						Value += 10;
				}
				else if(VecButton[5].ButtonSpite.getGlobalBounds().contains(pos.x, pos.y))
				{
					if(Value > 0)
						Value -= 10;
				}
				else if(VecButton[2].ButtonSpite.getGlobalBounds().contains(pos.x, pos.y))
				{
					if(isOpen == true)
					{
						VecButton[6].ButtonSpite.setPosition(0, 0);
						isOpen = false;
					}
					else 
					{
						VecButton[6].ButtonSpite.setPosition(1000, 1000);
						isOpen = true;
					}
				}
				else if(VecButton[7].ButtonSpite.getGlobalBounds().contains(pos.x, pos.y))
					{
						return 11;
					}
				else if(VecButton[8].ButtonSpite.getGlobalBounds().contains(pos.x, pos.y))
					{
						return 12;
					}
			}	
		}



		music.setVolume(Value);



		CurrentFrame += 0.005 * time;
		if(CurrentFrame > 3)
			CurrentFrame = 0;

		//cout << CurrentFrame;
		VecButton[0].ButtonSpite.setTextureRect(IntRect(0 + (int(CurrentFrame) * 800), 0, 800, 600));

		for (int i = 0; i < int(VecButton.size()); ++i)
				{
				Button But = VecButton[i];
				window.draw(But.ButtonSpite);
				}
		window.display();
	}

	return 0;
}