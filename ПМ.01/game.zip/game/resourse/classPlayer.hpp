#include "map.hpp"
#include "viev.hpp"

using namespace std;
using namespace sf;

class Player
{
public:
	float x, y, w, h, dx, dy, speed = 0, fx, fy;
	int PlayerPoint = 0;
	float CurrentFrame = 0;
	int dir = 1, health = 100;
	bool life = true, isPlayer = true;
	int BulGun = 1; // Подобрана ли пушка
	int zapas = 0;
	String File;
	Image image;
	Texture texture;
	Sprite sprite;

	Player(String F, float X, float Y, float W, float H, float dX, float dY)
	{
	File = F;
	w = W; h = H;	
	x = X; y = Y;
	dx = dX; dy = dY;
	image.loadFromFile("images/" + File);
	texture.loadFromImage(image);
	sprite.setTexture(texture);
	sprite.setTextureRect(IntRect(x, y, w, h));
 
	}

	void control(float time)
	{
		changeView();
		if(life == true)
		{
			if(Keyboard::isKeyPressed(Keyboard::Left))
			{
				dir = 1; speed = 0.2;
				CurrentFrame += 0.005 * time;
				if(CurrentFrame > 3)
					CurrentFrame = 0;

				sprite.setTextureRect(IntRect(16 + (int(CurrentFrame) * 100), 0, 61, 96));
				getPlayerCoordinateForView(sprite.getPosition().x, sprite.getPosition().y);
			}
			else if(Keyboard::isKeyPressed(Keyboard::Right))
			{
				dir = 0; speed = 0.2;
				CurrentFrame += 0.005 * time;
				if(CurrentFrame > 3)
					CurrentFrame = 0;
				
				sprite.setTextureRect(IntRect(77 + (int(CurrentFrame) * 100),0, -61,96));
				getPlayerCoordinateForView(sprite.getPosition().x, sprite.getPosition().y);
			}
			else if(Keyboard::isKeyPressed(Keyboard::Up))
			{
				dir = 3; speed = 0.2;
				CurrentFrame += 0.005 * time;
				if(CurrentFrame > 2)
					CurrentFrame = 0;

				sprite.setTextureRect(IntRect(222, 101 + (int(CurrentFrame) * 100), 51, 98));
				getPlayerCoordinateForView(sprite.getPosition().x, sprite.getPosition().y);
			}
			else if(Keyboard::isKeyPressed(Keyboard::Down))
			{
				dir = 2; speed = 0.2;
				CurrentFrame += 0.005 * time;
				if(CurrentFrame > 2)
					CurrentFrame = 0;

				sprite.setTextureRect(IntRect(222, 101 + (int(CurrentFrame) * 100), 51, 98));
				getPlayerCoordinateForView(sprite.getPosition().x, sprite.getPosition().y);
				}
			else
			{
				sprite.setTextureRect(IntRect(119,100,57,92));		
			}
		}
		else if(Keyboard::isKeyPressed(Keyboard::W)) //Тыкать если сдох
		{
			life = true;
			health = 100;//здоровеь снова 100
		}
		else
			sprite.setTextureRect(IntRect(0,200,100,100));
	}


	void update(float time)
	{
	switch(dir)
		{
		case 0: fx = speed; fy = 0; break;
		case 1: fx = -speed; fy = 0; break;
		case 2: fx = 0; fy = speed; break;
		case 3: fx = 0; fy = -speed; break;
		}
		dx += fx * time;
		dy += fy * time;

		speed = 0;
		sprite.setPosition(dx, dy);
		interactionWithMap();

		if(health <= 0)
			life = false;
	}


	void interactionWithMap()
	{
		for(int i = dy / 32; i < (dy + h) / 32; i++)
		for(int j = dx / 32; j < (dx + w) / 32; j++)
		{
			if(TileMap[i][j] == '0' || TileMap[i][j] == 'd'  || TileMap[i][j] == 'Z')
			{
				if (fy > 0)//если мы шли вниз,
							dy = i * 32 - h;//то стопорим координату игрек персонажа. сначала получаем координату нашего квадратика на карте(стены) и затем вычитаем из высоты спрайта персонажа.
				if (fy < 0)
							dy = i * 32 + 32;//аналогично с ходьбой вверх. dy<0, значит мы идем вверх (вспоминаем координаты паинта)
				if (fx > 0)
							dx = j * 32 - w;//если идем вправо, то координата Х равна стена (символ 0) минус ширина персонажа
				if (fx < 0)
							dx = j * 32 + 32;//аналогично идем влево
			}

			if(isPlayer == true)
			{
				if(TileMap[i][j] == 'p') //Взятие объекта PY
				{
					PlayerPoint++;
					health -= 40;
					TileMap[i][j] = ' ';
				}
				if(TileMap[i][j] == 'P') //Взятие объекта PY
				{
					PlayerPoint++;
					health -= 40;
					TileMap[i][j] = 'k';
				}
				if(TileMap[i][j] == 'z') //Взятие объекта zelie
				{
					zapas += 1;
					TileMap[i][j] = ' ';
					randPy('z');
				}
			}
		}
	}
};

class Entity : public Player
{
public:
	bool dv = false; // что б много питонов не спавнили
	Entity(String F, float X, float Y, float W, float H, float dX, float dY) : Player(F, X, Y, W, H, dX, dY)
	{
	isPlayer = false;
	}

void Artificial_Intelligence(float time)
	{
		int randGus = 1 + rand() % 10;
			if (randGus == 1 || randGus == 5) 
			{ 
				dir = 1; speed = 0.2; dv = true;
				CurrentFrame += 0.005 * time;
				if(CurrentFrame > 3)
					CurrentFrame = 0;

				sprite.setTextureRect(IntRect(0 + (int(CurrentFrame) * 100), 0, 100, 100));
			} 
			if (randGus == 2 || randGus == 6)
			{  	
				dir = 0; speed = 0.2; dv = true;
				CurrentFrame += 0.005 * time;
				if(CurrentFrame > 3)
					CurrentFrame = 0;

				sprite.setTextureRect(IntRect(0 + (int(CurrentFrame) * 100), 0, 100, 100));
			}
			if (randGus == 3 || randGus == 7)
			{  
				dir = 3; speed = 0.2; dv = true;
				CurrentFrame += 0.005 * time;
				if(CurrentFrame > 3)
					CurrentFrame = 0;

				sprite.setTextureRect(IntRect(0 + (int(CurrentFrame) * 100), 0, 100, 100));
			} 
			if (randGus == 4 || randGus == 8)
			{ 
				dir = 2; speed = 0.2; dv = true;
				CurrentFrame += 0.005 * time;
				if(CurrentFrame > 3)
					CurrentFrame = 0;

				sprite.setTextureRect(IntRect(0 + (int(CurrentFrame) * 100), 0, 100, 100));
			}
			if (randGus == 9 && TileMap[(int)sprite.getPosition().y / 32][(int)sprite.getPosition().x / 32] != '0' && dv == true)
			{
				if(TileMap[(int)sprite.getPosition().y / 32][(int)sprite.getPosition().x / 32] == ' ')
				 	TileMap[(int)sprite.getPosition().y / 32][(int)sprite.getPosition().x / 32] = 'p';
				if(TileMap[(int)sprite.getPosition().y / 32][(int)sprite.getPosition().x / 32] == 'k')
				 	TileMap[(int)sprite.getPosition().y / 32][(int)sprite.getPosition().x / 32] = 'P';
				 dv = false;
			}
	}
		
};


class Objects : public Player
{
public:
	//float distance = 0;
	float rotation = 0;
	float VecX = 0, VecY = 0;
	bool shot = false;

	Objects(String F, float X, float Y, float W, float H, float dX, float dY) : Player(F, X, Y, W, H, dX, dY)
	{
	sprite.setPosition(dx, dy);
	isPlayer = false;
	sprite.setOrigin(w / 2, h / 2);
	}
	
	void strelba(float time , bool isMove, float posX, float posY, vector<Entity>  &Entit)
	{
		if(isMove)
		{
			//	distance = sqrt((posX - sprite.getPosition().x - 50)*(posX - sprite.getPosition().x  - 50) + (posY - sprite.getPosition().y)*(posY - sprite.getPosition().y));//считаем дистанцию (длину от точки А до точки Б). формула длины вектора
			for(int i = 0; i < int(Entit.size()) && shot == false; i++)
				{	
					if(sprite.getGlobalBounds().intersects(Entit[i].sprite.getGlobalBounds()))
					{
						Entit[i].health -= 40;
						shot = true;
						//cout << Entit[i].health << endl;
						Entit[i].sprite.setColor(Color::Red);
						if(Entit[i].health < 0)
						{
						Entit.erase(Entit.begin() + i);
						}
					}
				};
				//cout <<  << endl;
			if (shot != true)
			{//этим условием убираем дергание во время конечной позиции спрайта
				if(TileMap[(int)sprite.getPosition().y / 32][(int)sprite.getPosition().x / 32] != '0' && TileMap[(int)sprite.getPosition().y / 32][(int)sprite.getPosition().x / 32] != 'd' && TileMap[(int)sprite.getPosition().y / 32][(int)sprite.getPosition().x / 32] != 'Z')
				{
					float lineX = dx - posX;
					float lineY = dy - posY;
					float line = sqrt((lineX * lineX) + (lineY * lineY));
					float Xx = (lineX / (line));
					float Yy = (lineY / (line));
					//cout << (Xx * Xx) +(Yy * Yy) << endl;
					sprite.move(-(2 * Xx) * time, -(2 * Yy) * time);
				}
			}
			else
				isMove = false;
		}
	}
	// 

	int Rotations(bool Gun, bool life, float pos_x, float pos_y, float p_dx, float p_dy, Sprite A)
	{
		if(Gun == true && life == true)
		{
			VecX  = pos_x - p_dx;//вектор , колинеарный прямой, которая пересекает спрайт и курсор
			VecY = pos_y - p_dy;//он же, координата y
			rotation = (atan2(VecY, VecX)) * 180 / 3.14159265;//получаем угол в радианах и переводим его в градусы
		
			sprite.setRotation(rotation);//поворачиваем спрайт на эти градусы

			if(rotation >= -90 && rotation <= 90)
			{
				sprite.setTextureRect(IntRect(160, 0, 64, 32));
				sprite.setPosition(A.getPosition().x + 30, A.getPosition().y + 45);
			}
			else
			{
				sprite.setTextureRect(IntRect(160, 32, 64, -32));
				sprite.setPosition(A.getPosition().x + 20, A.getPosition().y + 45);
			}
		}
		return rotation;
	}
};