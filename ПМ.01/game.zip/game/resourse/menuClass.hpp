using namespace std;
using namespace sf;

class Button
{
public:
	float x, y, w, h, dx, dy;
	string F;
	Image ButtonImage;
	Texture ButtonTexture;
	Sprite ButtonSpite;

	Button(string File, float X, float Y, float W, float H, float dX, float dY)
	{
		F = File;
		w = W; h = H;	
		x = X; y = Y;
		dx = dX; dy = dY;
		ButtonImage.loadFromFile("images/" + File);
		ButtonTexture.loadFromImage(ButtonImage);
		ButtonSpite.setTexture(ButtonTexture);
		ButtonSpite.setTextureRect(IntRect(x, y, w, h));
		ButtonSpite.setPosition(dx, dy);
	}
	
};