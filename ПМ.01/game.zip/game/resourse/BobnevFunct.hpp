#include "classPlayer.hpp"

using namespace std;
using namespace sf;

int BobnevGame()
{
	RenderWindow window(VideoMode(1200, 800), "BobnevSosi");
	view.reset(FloatRect(0, 0, 1000, 1000));

	bool BulGun = false; // Подобрана ли пушка
	int posX1, posY1, posX2, posY2; //вычисление координат
	char a[10] = "lox";
	Clock clock;
	float rotation = 0;
	bool isMove = false;
	int Zaderzka = 4;
	int ZaderzkaG = 9;
	int ZaderzkaZ = 0;
	float shotRed = 0;
	srand(time(0));
	int Value = 20;
	float respavn = 0;

	vector<float> tempX; //координаты курсора в пулю
	vector<float> tempY;
	vector<int> pX; //координаты игрока в пули
	vector<int> pY;

	Player p("Hero.png", 15, 0, 61, 96, 500, 600);

    vector<Entity>VecEntity;

    for(int i = 0; i < 12; i++)
    {
    	VecEntity.push_back(Entity("Gus.png", 0, 0, 100, 100, 1700, 2300));
    }
    

	Font font;
	font.loadFromFile("FontText.otf");

	Text text;
	text.setFont(font);
	text.setString(a);
	text.setCharacterSize(32);
	text.setFillColor(Color::Black);
	text.setStyle(Text::Bold);

	Text text1;
	text1.setFont(font);
	text1.setString(a);
	text1.setCharacterSize(20);
	text1.setFillColor(Color::Black);
	text1.setStyle(Text::Bold);
//========================================
	Image map_image;
	map_image.loadFromFile("images/itemsAll.png");
	map_image.createMaskFromColor(Color(255, 255, 255));
	Texture map;
	map.loadFromImage(map_image);
	Sprite s_map;
	s_map.setTexture(map);

	SoundBuffer BufShot; 
	BufShot.loadFromFile("soung/Shot.ogg");
	Sound shotS;
	shotS.setBuffer(BufShot);

	
	vector<Objects> VecObjects;
	vector<Objects> VecBullets;
/*		VecBullets.push_back(Objects("itemsAll.png", 226, 2, 12, 7, 0, 0)); //Пуля
		VecBullets[0].sprite.setOrigin(-64, 3);*/
		VecObjects.push_back(Objects("itemsAll.png", 160, 0, 64, 32, 300, 330)); //Пушка
		VecObjects[0].sprite.setOrigin(32, 16);

//========================================
	Music fon;
	fon.openFromFile("soung/Fon.ogg");
	fon.play();

	while(window.isOpen())
	{
		srand(time(NULL));
		float time = clock.getElapsedTime().asMicroseconds();
		clock.restart();
		time = time / 800;
		
		fon.setVolume(Value);
		

		Vector2i pixelPos = Mouse::getPosition(window);//забираем коорд курсора
		Vector2f pos = window.mapPixelToCoords(pixelPos);//переводим их в игровые (уходим от коорд окна)

		Event work;
		while(window.pollEvent(work))
		{
			if(work.type == Event::Closed)
				window.close();
		}

	
//ДВИЖЕНИЕ===================================
	p.control(time);

	if(p.life == true)
	{
		if(Keyboard::isKeyPressed(Keyboard::R))
		{
			if(BulGun == false)
				if(p.sprite.getGlobalBounds().intersects(VecObjects[0].sprite.getGlobalBounds()))
							BulGun = true;
		
		}
		else if(Keyboard::isKeyPressed(Keyboard::Q))
			BulGun = false;

		else if (Mouse::isButtonPressed(Mouse::Left) && BulGun == true)
		{
			
			if(Zaderzka == 5)
			{
				shotS.play();

				VecBullets.push_back(Objects("itemsAll.png", 226, 2, 12, 7, VecObjects[0].sprite.getPosition().x, VecObjects[0].sprite.getPosition().y - 5));  //Пуля
				VecBullets[VecBullets.size() - 1].sprite.setRotation(rotation);
				isMove = true;
				tempX.push_back(pos.x);//забираем координату нажатия курсора Х
				tempY.push_back(pos.y);//забираем координату нажатия курсора Y
				Zaderzka = 0;
			}
			else
				Zaderzka++;

			if(VecBullets.size() > 30)
			{
				VecBullets.erase(VecBullets.begin());
				tempX.erase(tempX.begin());
				tempY.erase(tempY.begin());
			}
			cout << pos.x << " " << pos.y << endl;
		}
		else if(Keyboard::isKeyPressed(Keyboard::G))
		{
			if(ZaderzkaG == 10)
			{
				VecEntity.push_back(Entity("Gus.png", 0, 0, 100, 100, p.sprite.getPosition().x, p.sprite.getPosition().y));
				ZaderzkaG = 0;
			}
			else
				ZaderzkaG++;
		}
		else if(Keyboard::isKeyPressed(Keyboard::P))
		{
			if(Value < 100)
				Value += 1;
		}
		else if(Keyboard::isKeyPressed(Keyboard::L))
		{
			if(Value > 0)
				Value -= 1;
		}
		else if(Keyboard::isKeyPressed(Keyboard::T))
		{
			if(p.zapas > 0 && ZaderzkaZ > 10)
			{
				if(p.health < 100)
				{
				p.health += 20;
				p.zapas -= 1;
				}
				ZaderzkaZ = 0;
			}
			else
				ZaderzkaZ++;
		}
	}	

	/*for(int i = 0; i < int(VecBullets.size()); ++i)
	{
		if(VecBullets[i].BulletFly == true || VecBullets[i].distance > 2)
		{
		VecBullets[i].strelba(time, isMove, tempX, tempY, VecEntity);
		VecBullets[i].BulletFly = false;
		}
	}*/
	for(int i = 0; i < int(VecBullets.size()); ++i)
	{
		VecBullets[i].strelba(time, isMove, tempX[i], tempY[i], VecEntity);
		if((VecBullets[i].sprite.getPosition().x > 1920 || VecBullets[i].sprite.getPosition().x < 0) || (VecBullets[i].sprite.getPosition().y > 2688 || VecBullets[i].sprite.getPosition().y < 0))
			{
				VecBullets.erase(VecBullets.begin() + i);
				tempX.erase(tempX.begin() + i);
				tempY.erase(tempY.begin() + i);
			}
	}
		
	respavn += time;
	if(respavn > 5000)
	{
		VecEntity.push_back(Entity("Gus.png", 0, 0, 100, 100, 1700, 2300));
		respavn = 0;
	}
	
		//cout << true;
////=======================================
	rotation = VecObjects[0].Rotations(BulGun, p.life, pos.x, pos.y, p.dx, p.dy, p.sprite);
	
//===================================

		p.update(time);

		shotRed += 0.005 * time;
		//cout << shotRed << endl;
		for(int i = 0; i < int(VecEntity.size()); ++i)
		{
			VecEntity[i].update(time);
			VecEntity[i].Artificial_Intelligence(time);
		}
		if(int(shotRed) > 3)
		{
			for(int i = 0; i < int(VecEntity.size()); ++i)
			{
				VecEntity[i].sprite.setColor(Color::White);
			}
			//cout << "RABOTYAI TVAR";
			shotRed = 0;
		}

		posX1 = p.sprite.getPosition().x;
		posY1 = p.sprite.getPosition().y;
		posX2 = VecObjects[0].sprite.getPosition().x;
		posY2 = VecObjects[0].sprite.getPosition().y;
		
	

		window.setView(view);
		window.clear(Color::White);

		for(int i = 0; i < HEIGHT_MAP; i++)
			for (int j = 0; j < WIDTH_MAP; j++)
			{
				if (TileMap[i][j] == '0')  s_map.setTextureRect(IntRect(0, 0, 32, 32)); //если встретили символ пробел, то рисуем 1й квадратик
				if (TileMap[i][j] == ' ')  s_map.setTextureRect(IntRect(32, 0, 32, 32));//если встретили символ s, то рисуем 2й квадратик
				if (TileMap[i][j] == 's')  s_map.setTextureRect(IntRect(64, 0, 32, 32));//если встретили символ 0, то рисуем 3й квадратик
				if (TileMap[i][j] == 'p')  s_map.setTextureRect(IntRect(96, 0, 32, 32));//если встретили символ 0, то рисуем 3й квадратик
				if (TileMap[i][j] == 'P')  s_map.setTextureRect(IntRect(224, 64, 32, 32));//если встретили символ 0, то рисуем 3й квадратик
				if (TileMap[i][j] == 'z')  s_map.setTextureRect(IntRect(128, 0, 32, 32));
				if (TileMap[i][j] == 'k')  s_map.setTextureRect(IntRect(160, 64, 32, 32));
				if (TileMap[i][j] == 'd')  s_map.setTextureRect(IntRect(224, 32, 32, 32));
				if (TileMap[i][j] == 'Z')  s_map.setTextureRect(IntRect(160, 32, 32, 32));
				if (TileMap[i][j] == 'V')  s_map.setTextureRect(IntRect(32, 32, 32, 32));
				if (TileMap[i][j] == 'F')  s_map.setTextureRect(IntRect(0, 32, 32, 32));
				if (TileMap[i][j] == 'f')  s_map.setTextureRect(IntRect(128, 64, 32, 32));
				if (TileMap[i][j] == 'D')  s_map.setTextureRect(IntRect(96, 32, 32, 32));
				if (TileMap[i][j] == 'S')  s_map.setTextureRect(IntRect(128, 32, 32, 32));
					
 
			s_map.setPosition(j * 32, i * 32);//по сути раскидывает квадратики, превращая в карту. то есть задает каждому из них позицию. если убрать, то вся карта нарисуется в одном квадрате 32*32 и мы увидим один квадрат
 			
			window.draw(s_map);//рисуем квадратики на экран
			}
			
		//нижний правый угол
		ostringstream playerScore;
		ostringstream playerHealth;
		playerScore << p.PlayerPoint;
		playerHealth << p.health << " " << p.zapas;
		text.setString("Lox: " + playerScore.str() + "\nHeatlh: " + playerHealth.str());
		text.setPosition(view.getCenter().x + 300, view.getCenter().y + 400);

		//нижний левый угол
		ostringstream x1;
		x1 << posX1 << " " << posY1 << " " << posX2 << " " << posY2;
		text1.setString(x1.str());
		text1.setPosition(view.getCenter().x - 300, view.getCenter().y + 400);

		window.draw(p.sprite);
		window.draw(text);
		window.draw(text1);

		for (int i = 0; i < int(VecObjects.size()); ++i)
				{
				Objects Obj = VecObjects[i];
				window.draw(Obj.sprite);
				}
		for (int i = 0; i < int(VecBullets.size()); ++i)
				{
				Objects Bull = VecBullets[i];
				window.draw(Bull.sprite);
				}

		for (int i = 0; i < int(VecEntity.size()); ++i)
				{
				Entity Gus = VecEntity[i];
				window.draw(Gus.sprite);
				}

		window.display();
	}
	

	return 0;
}