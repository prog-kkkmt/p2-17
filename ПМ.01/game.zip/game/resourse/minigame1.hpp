using namespace std;
using namespace sf;

int KrestNol()
{
	RenderWindow window(VideoMode(600, 700), "GameKO");

	int masMain[3][3];
	int a = 4, b = 4, xod = 0, KrNO, gg = 0, kk = 0;
	bool game = true;
	char TEXT[6] = "Win: ";

	for(int i = 0; i < 3; i++)
		for(int j = 0; j < 3; j++)
			masMain[i][j] = 2;

	Image Pole;
	Pole.loadFromFile("images/MiniGame/Pole.png");
	Texture PoleT;
	PoleT.loadFromImage(Pole);
	Sprite PoleS;
	PoleS.setTexture(PoleT);

	Font font;
	font.loadFromFile("FontText.otf");

	Text text;
	text.setFont(font);
	text.setString(TEXT);
	text.setCharacterSize(40);
	text.setFillColor(Color::Red);
	text.setPosition(50, 620);

	ostringstream x1;

	while(window.isOpen())
	{
		Vector2i Pos = Mouse::getPosition(window);//забираем коорд курсора
		Vector2f pixelPos = window.mapPixelToCoords(Pos);
		//смотрим на координату Х позиции курсора в консоли (она не будет больше ширины окна)

		Event work;
		while(window.pollEvent(work))
		{
			if(work.type == Event::Closed || Keyboard::isKeyPressed(Keyboard::X))
				window.close();
			else if(Keyboard::isKeyPressed(Keyboard::Z))
			{
				window.close();
				KrestNol();
			}
		}
			if(game)
			{
				a = pixelPos.x / 200;
				b = pixelPos.y / 200;
				if (Mouse::isButtonPressed(Mouse::Left) && kk != 9 && masMain[b][a] == 2)//если нажата клавиша мыши
				{
					//cout << pixelPos.x << " " << pixelPos.y << "\n";
					if(pixelPos.x > 0 && pixelPos.y > 0)
					{
						
						
						KrNO = xod % 2;
						xod++;
						//cout << a << " " << b << "\n";
						//cout << "isClicked!\n";
						masMain[b][a] = KrNO;	
						kk++;
					}
					for(int i = 0; i < 3; i++)
					{
						if(masMain[i][0] == masMain[i][1] && masMain[i][1] == masMain[i][2] && masMain[i][0] != 2)
						{
							//cout << "\nWIN\n";
							game = false;
						}
						if(masMain[0][i] == masMain[1][i] && masMain[1][i] == masMain[2][i] && masMain[0][i] != 2)
						{
							//cout << "\nWIN\n";
								game = false;
						}
					}
					if(masMain[0][0] == masMain[1][1] && masMain[1][1] == masMain[2][2] && masMain[0][0] != 2)
						{
							//cout << "\nWIN\n";
							game = false;
						}
					if(masMain[0][2] == masMain[1][1] && masMain[1][1] == masMain[2][0] && masMain[0][2] != 2)
						{
							//cout << "\nWIN\n";
							game = false;
						}
						
				}
				else if(gg == 0 && kk == 9)
				{
					x1 << "draw";
					text.setString(TEXT + x1.str());
					text.setPosition(50, 620);
					gg = 1;
				}
			}
			else if(gg == 0)
			{ 
				if(KrNO == 0)
					x1 << "krestik";
				else
					x1 << "nolik";
				text.setString(TEXT + x1.str());
				text.setPosition(50, 620);
				gg = 1;

				
				//window.draw(PoleS);
			}
		
		

		for(int i = 0; i < 3; i++)
			for(int j = 0; j < 3; j++)
			{
			if(masMain[i][j] == 1)
				PoleS.setTextureRect(IntRect(0,0,200,200));
			if(masMain[i][j] == 0)
				PoleS.setTextureRect(IntRect(200,0,200,200));
			if(masMain[i][j] == 2)
				PoleS.setTextureRect(IntRect(400,0,200,200));

			PoleS.setPosition(j * 200, i * 200);
			window.draw(PoleS);
			}

		
		window.draw(text);
		window.display();
	}
	return 0;
}