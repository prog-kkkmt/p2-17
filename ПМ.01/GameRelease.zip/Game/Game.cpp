#include <iostream>
#include <vector>
#include <cstring>
#include <sstream>
#include <SFML/Graphics.hpp>

#include "resourse/MainMenu.hpp"

using namespace std;
using namespace sf;

int main()
{
	//Вызов фунции лаунчера
	launcher(); 
	return 0;
}