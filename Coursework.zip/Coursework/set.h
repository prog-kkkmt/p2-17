#ifndef SET_H
#define SET_H
#include <QString>

class Set
{
private:
    char *set;
    int size;
public:
    Set();
    Set addition(Set Set_A, Set Set_B);//Объединение множеств
    Set disjunction(Set Set_A, Set Set_B);//Пересечение множеств
    bool equality(Set Set_A, Set Set_B);//Проверка на равенство множеств
    Set difference(Set Set_A, Set Set_B);//Разность множеств
    Set symmetrical_difference(Set Set_A, Set Set_B);//Симметричная разность множеств
    bool subset(Set Set_A, Set Set_B);// Проверка является множество 'B' подмножеством 'A'
    Set get_set(QString text);
    QString get_text(Set data);
};

#endif // SET_H
