#include "cost.h"

cost::cost(string File)
{
	ifstream file(File.c_str());
	if (!(file.is_open()))
		cout << "File " << File << " not found" << endl;
	cost_struct temp_cost;
	while(file >> temp_cost.code >> temp_cost.name)
	{
		costs.push_back(temp_cost);
		cout << temp_cost.code << " " << temp_cost.name << endl;
	}
}

