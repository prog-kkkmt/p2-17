#include "section.h"

section::section(string File)
{
	ifstream file(File.c_str());
	if (!(file.is_open()))
		cout << "File " << File << " not found" << endl;
	section_struct temp_section;
	while(file >> temp_section.code_cost >> temp_section.name >> temp_section.code_state >> temp_section.ci)
	{
		sections.push_back(temp_section);
		cout << temp_section.code_cost << " " << temp_section.name << " " << temp_section.code_state << " " << temp_section.ci << endl;
	}
}