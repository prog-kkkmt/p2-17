#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

class cost
{
public:
	struct cost_struct
	{
	int code;
	string name;	
	};
	
	vector<cost_struct> costs;

	cost(string);
};