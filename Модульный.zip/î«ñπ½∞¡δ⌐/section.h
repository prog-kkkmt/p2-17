#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

class section
{
public:
	struct section_struct
	{
	int code_cost;
	int code_state;
	string ci;
	string name;	
	};
	
	vector<section_struct> sections;

	section(string);
};