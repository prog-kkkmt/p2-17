#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

class expenses
{
public:
	struct expenses_struct
	{
		int code_exp;
		int code_sect;
		string data;
		int count;
		int price;
	};

	int butg = 0;

	vector<expenses_struct> expens;

	expenses(string);

	void sum();
	void part();
};