#include "expenses.h"

expenses::expenses(string File)
{
	ifstream file(File.c_str());
	if (!(file.is_open()))
		cout << "File " << File << " not found" << endl;
	expenses_struct temp_expens;
	while(file >> temp_expens.code_exp >> temp_expens.code_sect >> temp_expens.data >> temp_expens.count >> temp_expens.price)
	{
		expens.push_back(temp_expens);
		cout << temp_expens.code_exp << " " << temp_expens.code_sect << " " << temp_expens.data << " " << temp_expens.count << " " << temp_expens.price << endl;
	}
}

void expenses::sum()
{
	for(int i = 0; i < expens.size(); i++)
	{
		butg += expens[i].price;
	}

	cout << butg << endl;
}

void expenses::part()
{
	for(int i = 0; i < expens.size(); i++)
	{
		double fpart;

		fpart = (double)expens[i].price/(double)butg * 100;
		cout << fpart << "%" << endl;
	}
}