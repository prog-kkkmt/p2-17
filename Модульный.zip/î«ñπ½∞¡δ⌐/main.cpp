#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "cost.cpp"
#include "section.cpp"
#include "expenses.cpp"

using namespace std;

int main()
{
	cout << "Table of cost:" << endl;
	cost costs("cost.txt");

	cout << "\nTable of section:" << endl;
	section sections("section.txt");

	cout << "\nTable of expenses:" << endl;
	expenses expens("expenses.txt");

	cout << "\nSum budget: ";
	expens.sum();

	cout << "\nPart of expenses:" << endl;
	expens.part();

	return 0;
}
