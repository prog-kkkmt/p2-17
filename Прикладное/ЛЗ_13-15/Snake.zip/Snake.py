import pygame
import sys

pygame.init()

class Snake(self,snake_color):
    def __init__(self):
        self.snake_head = [100,50]#x,y
        self.snake_body = [[100,50],[90,50],[80,50]]

        self.snake_color = snake_color

        self.direction_left = 'LEFT'
        self.direction_right = 'RIGHT'
        self.direction_up = 'UP'
        self.direction_down = 'DOWN'
        self.click_to = self.direction

    def going(self):
        if any((self.click_to = 'RIGHT' and not self.direction == 'LEFT',self.click_to = 'LEFT' and not self.diretion == 'RIGHT',self.click_to = 'UP' and not self.direction == 'DOWN',self.click_to = 'DOWN' and not self.direction == 'UP'))
            self.direction = self.click_to






    def length(self):
        if
