import pygame
import sys

WIN_HEIGHT = 400
WIN_WINTH = 800

ORANGE = (255, 150, 100)
WHITE = (255, 255, 255)

pygame.init()

clock = pygame.time.Clock()

gg = pygame.display.set_mode((WIN_WINTH,WIN_HEIGHT))
pygame.display.set_caption("Snake")
#f1 = pygame.font.SysFont('serif',30)
#text1 = f1.render('Hello',)

r = 30
now = True
x = WIN_WINTH // 2
y = WIN_HEIGHT // 2


while now:
    gg.fill(WHITE)
    events = pygame.event.get()

    surf = pygame.Surface((290, 400))
    surf.fill((255, 0, 0))
    gg.blit(surf, (10, 10))

    pygame.draw.circle(gg, ORANGE, (x, y), r)

    for event in events:
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.K_ESCAPE:
            pygame.quit()
            sys.exit()


    keys = pygame.key.get_pressed()#

    if keys[pygame.K_LEFT]:#зажатие
        x -= 5
    elif keys[pygame.K_RIGHT]:
        x += 5
    elif keys[pygame.K_UP]:
        y -= 5
    elif keys[pygame.K_DOWN]:
        y += 5

    #if x >= WIN_WINTH + r:
     #   x = 0 - r
    #else :
     #   x += 2
    pygame.display.update()

    clock.tick(60)