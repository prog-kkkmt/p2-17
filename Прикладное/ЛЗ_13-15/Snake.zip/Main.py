import pygame
import Snake
import sys

pygame.init()

class Game():


    def __init__(self):
        self.win_width = 720#обращение к объекту через self
        self.win_height = 460

        self.green = pygame.Color(0,128,0)
        self.orange = pygame.Color(255,165,0)
        self.yellow = pygame.Color(255,255,0)
        self.blue = pygame.Color(0,0,255)

        self.fps = pygame.time.Clock()

        self.score = 0

    def dis_init(self):
        self.display_play = pygame.display.set_mode((self.win_width,self.win_height))
        pygame.display.set_caption('Snake')

    def __Event__(self,klick_to):
        for event in pygame.event.get()
            if event.key == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    klick_to = 'RIGHT'
                elif event.key == pygame.K_LEFT:
                    klick_to = 'LEFT'
                elif event.key == pygame.K_UP:
                    klick_to = 'UP'
                elif event.key == pygame.K_DOWN:
                    klick_to = 'DOWN'
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
        return klick_to:

    def update_screen(self):
        pygame.display.flip()
        Game.display_play.tick(30)

